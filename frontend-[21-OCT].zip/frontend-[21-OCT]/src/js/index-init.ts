import "./aos";
import "./faq";
import "./how-it-works";
