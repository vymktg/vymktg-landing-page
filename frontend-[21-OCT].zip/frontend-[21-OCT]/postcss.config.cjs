module.exports = {
    plugins: [
        require('tailwindcss/nesting'),
        require('tailwindcss')
    ],
}